'use strict'

const t = require('tap')
require('./helper').payloadMethod('options', t)
require('./input-validation').payloadMethod('options', t)
