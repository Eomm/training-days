'use strict'

const t = require('tap')
require('./helper').payloadMethod('put', t)
require('./input-validation').payloadMethod('put', t)
